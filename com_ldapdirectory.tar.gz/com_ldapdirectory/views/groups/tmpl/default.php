<?php
/**
 * $Id: default.php 13339 2009-10-27 02:27:05Z ian $
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

?>

This is a test

